
import { Payment } from "./payment";
import { Productinfo } from "./productcopy";
import { Registerinfo } from "./register";

export interface Order {
    
    order_id:number;
   
    address:string;
    quantity:string;
    // payment_id:number;
    payment:Payment;
   


    product:Productinfo;
    // menu_id:number;
    // dish_name:string;
    // description:string;
    // dish_price:number;
    // availablity:string;
    // delivery_fee:string;
    // curations:string;

    user:Registerinfo
    // user_id:number;
    // first_name:string;
    // lastname:string;
    // city:string;
    // email_id:string;
    // phone_no:number;
    // password:string;
    // state:string;

  
    
}



