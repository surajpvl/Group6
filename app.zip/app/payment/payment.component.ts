import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Order } from '../order';
import { OrderService } from '../order.service';
import { Orderinfo } from '../ordercopy';
import { Payment } from '../payment';
import { Product } from '../product';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
payment:Payment;
order:Order;
submitted = false;
  constructor(private _orderservice:OrderService,private router:Router) {

    this.order=JSON.parse(localStorage.getItem('orderobj') || '{}') as Order;
    this.payment=new Payment("",0,new Date ());
   }
   onSubmit() :void{
     console.log("order="+JSON.stringify(this.order))
     console.log("payment="+JSON.stringify(this.payment))
    this._orderservice.addpayment(this.payment).subscribe((data: any) => {
      console.log(data+" "+this.payment)
      // this.order = new Orderinfo(new Product());
      let payment=(data as Payment)
   let  paymentid=(  payment).payment_id;
  //  this.order.payment_id=paymentid;
   this.order.payment=payment;
    this._orderservice.createOrder(this.order).subscribe((data1 : any)=>{
      console.log(data1+" "+this.order)
     this.submitted = true;
     alert("order placed sucessfully")
      this.gotoList();
    }
    ,error1 => console.log(error1)
    )
     
    },
   error => console.log(error));

   }
   gotoList() {
    this.router.navigate(['/products']);
  }
  ngOnInit(): void {

  }

}
