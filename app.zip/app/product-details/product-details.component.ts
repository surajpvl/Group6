import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
 
  menu_id: number=0;
  product: Product=new Product();

  constructor(private route: ActivatedRoute,private router: Router,private productService: ProductService) { }

  ngOnInit() {
    this.product = new Product();

    this.menu_id = this.route.snapshot.params['menu_id'];
    sessionStorage.setItem ("menuid",this.menu_id.toString())
    this.productService.getProduct(this.menu_id)
      .subscribe(data => {
        console.log(data)
        this.product = data;
        sessionStorage.setItem("menuobj",JSON.stringify(this.product))
      }, error => console.log(error));
      //this.list();
  }

  list(){
    this.router.navigate(['/products']);
  }
}
