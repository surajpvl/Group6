import { Productcopy } from './productcopy';

describe('Productcopy', () => {
  it('should create an instance', () => {
    expect(new Productcopy()).toBeTruthy();
  });
});
