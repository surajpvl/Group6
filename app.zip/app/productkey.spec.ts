import { Productkey } from './productkey';

describe('Productkey', () => {
  it('should create an instance', () => {
    expect(new Productkey()).toBeTruthy();
  });
});
