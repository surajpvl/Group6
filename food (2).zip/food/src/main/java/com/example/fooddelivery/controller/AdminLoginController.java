package com.example.fooddelivery.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


//import com.example.foodOrdering.service.AdminLoginService;
import com.example.fooddelivery.model.AdminLogin;
import com.example.fooddelivery.service.AdminLoginService;

@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/food")
@RestController
public class AdminLoginController {
	@Autowired
	AdminLoginService adminSer;
	
	@PostMapping("/admins")
	public AdminLogin validateALogin(@RequestBody AdminLogin adminlogin) 		
	{
//		System.out.println("Admin Works="+adminlogin.getEmail_id());
		
		
		AdminLogin a = adminSer.validateAdminLogin(adminlogin);
		return a;
	}
}
