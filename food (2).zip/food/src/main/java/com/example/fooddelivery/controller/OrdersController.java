package com.example.fooddelivery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.fooddelivery.exception.ResourceNotFoundException;
import com.example.fooddelivery.model.Orders;
import com.example.fooddelivery.service.OrdersService;

@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/food")
@RestController
public class OrdersController {
	
    @Autowired
	OrdersService orderSer;
    
    @GetMapping("/orders")
	public List<Orders> getOrders() {
		List<Orders> ordList = orderSer.fetchOrder();
		return ordList;
	}
    
    @GetMapping("/orders/{Id}")
	public ResponseEntity<Orders> getOrderById(@PathVariable("Id") int orderId) throws ResourceNotFoundException {
		Orders order = orderSer.getOrder(orderId);
		return ResponseEntity.ok().body(order);
	}
    
    @PostMapping("/orders")
	public Orders addneworder(@RequestBody Orders ord) {
		Orders order = orderSer.saveOrder(ord);
		return order;
	}
    
    
    @DeleteMapping("/orders/{id}")
	public ResponseEntity<String> deleteOrder(@PathVariable("id") int ordId) {
		orderSer.deleteOrder(ordId);
		return (ResponseEntity<String>) new ResponseEntity<>(" Deleted successsfully", HttpStatus.OK);
	}
    
}
