package com.example.fooddelivery.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.fooddelivery.model.Menu;
import com.example.fooddelivery.model.Payment;
import com.example.fooddelivery.service.PaymentService;

@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/food")
@RestController
public class PaymentController {
 
	@Autowired
	PaymentService paySer;
	
	@PostMapping("/transactions")
	public Payment addPayment(@RequestBody Payment pay) {
		Payment menu = paySer.savePay(pay);
		return menu;
	}
}
