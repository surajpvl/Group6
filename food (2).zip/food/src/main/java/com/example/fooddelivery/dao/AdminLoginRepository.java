package com.example.fooddelivery.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.fooddelivery.model.AdminLogin;

@Repository
public interface AdminLoginRepository extends JpaRepository<AdminLogin, String>{

	@Query("SELECT al FROM AdminLogin al WHERE al.email_id =?1 and al.password=?2")
	public AdminLogin validateAdminLogin(String email_id,String password);
}
