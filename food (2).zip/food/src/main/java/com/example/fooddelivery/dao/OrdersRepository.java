package com.example.fooddelivery.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.fooddelivery.model.Orders;


public interface OrdersRepository extends JpaRepository< Orders,Integer>  {

}
