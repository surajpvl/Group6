package com.example.fooddelivery.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="Menu")
public class Menu {

	@Id
	@Column(name="menuId")
 	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int menu_id;
	
	@Column(name="dishName")
	private String dish_name;
	
	@Column(name="dishPrice")
	private int dish_price;
	
	@Column(name="availablity")
	private String availablity;
	
	@Column(name="description")
	private String description;
	
	@Column(name="curations")
	private String curations;
	
	@Column(name="deliveryFee")
	private String delivery_fee;

	public Menu(int menuid, String dishname, int price, String availablity, String description, String curations,
			String deliveryfee) {
		super();
		this.menu_id = menuid;
		this.dish_name = dishname;
		this.dish_price = price;
		this.availablity = availablity;
		this.description = description;
		this.curations = curations;
		this.delivery_fee = deliveryfee;
	}

	public Menu() {
		
	}
	@JsonProperty("menu_id")
	public int getMenuid() {
		return menu_id;
	}

	public void setMenuid(int menuid) {
		this.menu_id = menuid;
	}
	@JsonProperty("dish_name")
	public String getDishname() {
		return dish_name;
	}

	public void setDishname(String dishname) {
		this.dish_name = dishname;
	}
	@JsonProperty("dish_price")
	public int getPrice() {
		return dish_price;
	}

	public void setPrice(int price) {
		this.dish_price = price;
	}

	public String getAvailablity() {
		return availablity;
	}

	public void setAvailablity(String availablity) {
		this.availablity = availablity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCurations() {
		return curations;
	}

	public void setCurations(String curations) {
		this.curations = curations;
	}
	@JsonProperty("delivery_fee")
	public String getDeliveryfee() {
		return delivery_fee;
	}

	public void setDeliveryfee(String deliveryfee) {
		this.delivery_fee = deliveryfee;
	}
	
}
