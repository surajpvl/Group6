package com.example.fooddelivery.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddelivery.dao.MenuRepository;
import com.example.fooddelivery.model.Menu;


@Service
public class MenuService {

	@Autowired
	MenuRepository menuRep;
	
	@Transactional
	public List<Menu> fetchAllMenu() {
		List<Menu> menuList=menuRep.findAll();
		return menuList;
	}
	@Transactional 
	  public Menu getMenuById(int id) { 
	  Optional<Menu> optional=menuRep.findById(id);
	  Menu pro=optional.get();
	  return pro;
	  }
	
	@Transactional
	public Menu saveMenu(Menu menu) {		
		return menuRep.save(menu);		
	}
	
	@Transactional
	public void updateMenu(Menu menu) {
		menuRep.save(menu);		
	}
	
	@Transactional
	public void deleteMenuById(int menuId) {
		System.out.println("Deleted ");
		menuRep.deleteById(menuId);	
	}
}
