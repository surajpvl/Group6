package com.example.foodOrdering.demo;

import org.junit.jupiter.api.TestMethodOrder;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.fooddelivery.dao.AdminLoginRepository;
import com.example.fooddelivery.demo.FoodOrderingApplication;
import com.example.fooddelivery.model.AdminLogin;

@SpringBootTest(classes=FoodOrderingApplication.class)
@TestMethodOrder(OrderAnnotation.class)
public class AdminTest {

	@Autowired
	AdminLoginRepository arepo;
	
	@Test
	public void showadmin() {
		List<AdminLogin> list=arepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
}
