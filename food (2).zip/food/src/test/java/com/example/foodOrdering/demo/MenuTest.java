package com.example.foodOrdering.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

//import com.crud.model.Employee;
import com.example.fooddelivery.dao.MenuRepository;
import com.example.fooddelivery.demo.FoodOrderingApplication;
import com.example.fooddelivery.model.Menu;

@SpringBootTest(classes=FoodOrderingApplication.class)
@TestMethodOrder(OrderAnnotation.class)
class MenuTest {
   
	@Autowired
	MenuRepository mrepo;
	
	
	@Test
	@Order(1)
	public void menuCreate()
	{
		Menu m=new Menu();
		
		m.setDishname("dosa");
		m.setPrice(100);
		m.setAvailablity("Yes");
		m.setDescription("abcd");
		m.setCurations("Indian");
		m.setDeliveryfee("20");
		mrepo.save(m);
		assertNotNull(mrepo.findById(2).get());
	}
	
	@Test
	@Order(2)
	public void menuRead()
	{
		List<Menu> list=mrepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	@Order(3)
	public void menuReadById()
	{
		 Menu m=mrepo.findById(2).get();
		 assertEquals("dosa",m.getDishname());
	}

	@Test
	@Order(4)
	public void menuupdate() {
		Menu m=mrepo.findById(2).get();
		m.setPrice(150);
		mrepo.save(m);
		assertNotEquals(100, mrepo.findById(2).get().getPrice());
	}
    @Test
	@Order(5)
	public void  menuDelete()
	{
		mrepo.deleteById(2);
		assertThat(mrepo.existsById(2)).isFalse();
	}
   }
