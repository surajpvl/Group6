package com.example.foodOrdering.demo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.fooddelivery.dao.OrdersRepository;
import com.example.fooddelivery.demo.FoodOrderingApplication;

import com.example.fooddelivery.model.Orders;

@SpringBootTest(classes=FoodOrderingApplication.class)
@TestMethodOrder(OrderAnnotation.class)
public class OrdersTest {

	@Autowired
	OrdersRepository orepo;
	
	@Test
	public void showorders() {
		List<Orders> list=orepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
}