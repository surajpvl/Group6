package com.example.foodOrdering.demo;

import org.junit.jupiter.api.TestMethodOrder;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


import com.example.fooddelivery.dao.PaymentRepository;
import com.example.fooddelivery.demo.FoodOrderingApplication;
import com.example.fooddelivery.model.Payment;

@SpringBootTest(classes=FoodOrderingApplication.class)
@TestMethodOrder(OrderAnnotation.class)
public class PaymentTest {

	@Autowired
	PaymentRepository prepo;
	
	@Test
	@Order(1)
	public void newpay() {
		Payment p=new Payment();
		p.setPayment_date("02-14-2022");
		p.setPayment_mode("gpay");
		prepo.save(p);
		assertNotNull(prepo.findById(15).get());
	}
	
	@Test
	@Order(2)
	public void payRead()
	{
		List<Payment> list=prepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	@Order(3)
	public void payReadById()
	{
		 Payment p=prepo.findById(15).get();
		 assertEquals("gpay",p.getPayment_mode());
	}

	@Test
	@Order(5)
	public void  regDelete()
	{
		prepo.deleteById(14);
		assertThat(prepo.existsById(14)).isFalse();
	}
}
