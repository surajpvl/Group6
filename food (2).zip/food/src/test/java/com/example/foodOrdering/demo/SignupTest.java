package com.example.foodOrdering.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


import com.example.fooddelivery.dao.SignupRepository;
import com.example.fooddelivery.demo.FoodOrderingApplication;

import com.example.fooddelivery.model.Signup;

@SpringBootTest(classes=FoodOrderingApplication.class)
@TestMethodOrder(OrderAnnotation.class)
class SignupTest {

	@Autowired
	SignupRepository srepo;
	
	
	@Test
	@Order(1)
	public void createSignup()
	{
		Signup s=new Signup();
	   
		s.setFirst_name("hemnath");
		s.setLast_name("ab");
		s.setCity("chennai");
		s.setState("TN");
		s.setEmail_id("abc@gmail.com");
		s.setPassword("asdf");
		s.setPhone_no("9874567894");
		srepo.save(s);
		assertNotNull(srepo.findById(8).get());
	}
	
	@Test
	@Order(2)
	public void signupRead()
	{
		List<Signup> list=srepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	@Order(3)
	public void signupReadById()
	{
		Signup m=srepo.findById(8).get();
		 assertEquals("TN",m.getState());
	}

	@Test
	@Order(4)
	public void regupdate() {
		Signup m=srepo.findById(8).get();
		m.setLast_name("zxc");;
		srepo.save(m);
		assertNotEquals("ab", srepo.findById(8).get().getLast_name());
	}
	@Test
	@Order(5)
	public void  regDelete()
	{
		srepo.deleteById(8);
		assertThat(srepo.existsById(8)).isFalse();
	}
}
